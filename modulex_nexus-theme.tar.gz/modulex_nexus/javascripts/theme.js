(() => {
  'use strict';

  const init = () => {
    const body = document.body;
    if (!body.classList.contains('controller-welcome') || !body.classList.contains('action-index')) return;

    const content = document.querySelector('#content');
    if (!content || content.querySelector('.mx-home')) return;

    const homeHref = document.querySelector('#top-menu a.home')?.getAttribute('href') || '/';
    const base = homeHref === '/' ? '' : homeHref.replace(/\/$/, '');
    const route = (path) => `${base}/${path}`;

    const landing = document.createElement('section');
    landing.className = 'mx-home';
    landing.setAttribute('aria-label', 'Module X command center');
    landing.innerHTML = `
      <div class="mx-home__hero">
        <div class="mx-home__copy">
          <div class="mx-kicker"><span></span> MODULE X / DIGITAL PROCESS</div>
          <h2>Operate with signal.<br><strong>Deliver with clarity.</strong></h2>
          <p>One focused workspace for product decisions, engineering execution, and delivery traceability.</p>
          <div class="mx-home__actions">
            <a class="mx-button mx-button--primary" href="${route('projects')}">Open projects</a>
            <a class="mx-button mx-button--ghost" href="${route('my/page')}">My workspace</a>
          </div>
        </div>
        <div class="mx-orbit" aria-hidden="true">
          <div class="mx-orbit__ring mx-orbit__ring--outer"></div>
          <div class="mx-orbit__ring mx-orbit__ring--inner"></div>
          <div class="mx-orbit__axis"></div>
          <div class="mx-orbit__core"><span>MX</span><small>NEXUS</small></div>
          <i class="mx-orbit__node mx-orbit__node--one"></i>
          <i class="mx-orbit__node mx-orbit__node--two"></i>
          <i class="mx-orbit__node mx-orbit__node--three"></i>
        </div>
      </div>

      <div class="mx-home__modules">
        <a class="mx-module" href="${route('projects')}">
          <span class="mx-module__index">01</span>
          <span class="mx-module__glyph mx-module__glyph--projects"></span>
          <span class="mx-module__body"><strong>Project Matrix</strong><small>Map teams, milestones, and delivery lanes.</small></span>
          <span class="mx-module__arrow">&#8599;</span>
        </a>
        <a class="mx-module" href="${route('activity')}">
          <span class="mx-module__index">02</span>
          <span class="mx-module__glyph mx-module__glyph--activity"></span>
          <span class="mx-module__body"><strong>Activity Stream</strong><small>Review the latest operational signals.</small></span>
          <span class="mx-module__arrow">&#8599;</span>
        </a>
        <a class="mx-module" href="${route('issues')}">
          <span class="mx-module__index">03</span>
          <span class="mx-module__glyph mx-module__glyph--issues"></span>
          <span class="mx-module__body"><strong>Issue Control</strong><small>Move critical work from risk to resolution.</small></span>
          <span class="mx-module__arrow">&#8599;</span>
        </a>
      </div>

      <div class="mx-home__status">
        <span><i class="mx-status-dot"></i> CORE / ONLINE</span>
        <span>REGION / AP-NORTHEAST</span>
        <span>PROCESS / TRACEABLE</span>
        <time class="mx-home__clock" aria-label="Taipei time"></time>
      </div>`;

    const title = content.querySelector(':scope > h2');
    const nativeHome = content.querySelector(':scope > .splitcontent');
    title?.classList.add('mx-native-title');
    nativeHome?.classList.add('mx-native-home');
    content.insertBefore(landing, title || content.firstChild);

    const clock = landing.querySelector('.mx-home__clock');
    const updateClock = () => {
      if (!clock) return;
      clock.textContent = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Taipei',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).format(new Date()) + ' / TPE';
    };
    updateClock();
    window.setInterval(updateClock, 1000);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
